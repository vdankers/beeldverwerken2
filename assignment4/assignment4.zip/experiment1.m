k = 1;
for i = 0.0:0.2:0.4
  for j = 0.5:0.2:0.9
    % 5 lines added for testing
    subplot(3,4,k)
    img = imread(strcat(images(1,:)));
    im = im2double(rgb2gray(img));
    h = hough(im,[i j],500,500);
    h = h / (max(max(h))/4);
    lines = houghlines(im, h, 1);
    %lines = houghlines_dilation(im, h, 1, 10);

    imshow(im)
    hold on;
    for n = 1:size(lines,1)
        line(lines(n, 1:2), lines(n, 3:4))
    end
    hold off;
    x = xlabel(sprintf('%s %s %s %s','Low ',num2str(i),'High',num2str(j)));
    set(x,'Interpreter','latex');
    k = k + 1
  end
end