%% plot_lines: plot edges detect by using hough transforms and adjusted by 
% total least squares on top of images
function plot_tls_lines(images)
  addpath('..');

  n_images = size(images,1);

  for i = 1:n_images
    subplot(1,n_images,i);
    imgname = strcat(images(i,:))
    img = imread(imgname);
    im = im2double(rgb2gray(img));

    % Perform hough transformation
    h = hough(im,[0.5 0.8],500,500);

    % Scale it down
    h = h / (max(max(h))/4);
    lines = houghlines(im, h, 1);
    %lines = houghlines_dilation(im, h, 1, 10);

    % pythonesque turning logical edge array into a 3 x n array with the
    % homogeneous representations of the edgepoints
    edges = edge(im, 'canny', [.5 .8]);
    k = find(edges);
    homopoints = zeros(3, size(k,1));
    count = 1;
    for i=1:size(edges,1)
       for j = 1:size(edges,2)
           if edges(i,j) == 1
               homopoints(:, count) = [i; j; 1];
               count = count+1;
           end
       end
    end

    % Further estimate lines with total least squares
    lines = lines_to_hom(lines);
    imshow(im)
    hold on;
    straight_lines = zeros(size(lines));
    for i = 1:size(lines,1)
      points = points_of_line(homopoints', lines(i,:), 30)
      if size(points) ~= 0
        l = line_through_points(points(:,1:2));
        a = l(1);
        b = l(2);
        c = l(3);
        x = linspace(0,size(im,2));
        y = (a*x - c)/ -b;
        plot(x,y);
        straight_lines(i,:) = l;
      end
    end
    
    x = xlabel(sprintf('%s %s','Edges of ',imgname));
    set(x,'Interpreter','latex');
  end
end

